# JC_2018
This repository stores all code for the analyses conducted for the Jatropha curcas manuscript completed in 2018. These experiments involved field and greenhouse experiments in Panama.

Folder Alphafiles contains all of the files that the alpha diversity R script requires

Folder Vegan contains all of the files for the Vegan analysis
